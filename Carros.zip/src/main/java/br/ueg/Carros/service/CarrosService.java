package br.ueg.Carros.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import br.ueg.Carros.model.Carro;
import br.ueg.Carros.repository.CarrosRepository;

@Service
public class CarrosService {

	
	@Autowired
	private CarrosRepository carrosRepository;

	
	public List<Carro> listar(){
		return carrosRepository.findAll();
	}
	public Carro getCarro(Integer id) {
		Optional<Carro> carro = obterCarrosSeExiste(id);
		
		return carro.get();
	}
	
	private Optional<Carro> obterCarrosSeExiste(Integer id) {
		Optional<Carro> carro = carrosRepository.findById(id);
		
			if(!carro.isPresent()) {
				throw new IllegalStateException("Não existe Carro com o ID: "+id);
			}
		return carro;
	}
	
	
	public Carro incluir(Carro carro) {
		Carro carrosRetorno = carrosRepository.save(carro);
		return carrosRetorno;
	}
	
	public List<Carro> getCarroByMarca(String marca){
		List<Carro> carros = carrosRepository.findByMarca(marca);
		if(CollectionUtils.isEmpty(carros)) {
			throw new IllegalAccessError ("Nenhuma Marca com esse nome: "+ marca);
		}
		return carros;
	}

	
	private Optional<Carro> obterCarroSeExiste(Integer id) {
		Optional<Carro> carro = carrosRepository.findById(id);
		return carro;
	}
	
	public Carro remover(Integer id) {
		Optional<Carro> carroOptional = obterCarroSeExiste(id);
		Carro carro = carroOptional.get();
		carrosRepository.delete(carro);		
		return carro;
	}

	public Carro alterar(Carro carro, Integer id) {
		Optional<Carro> carroOptional = obterCarrosSeExiste(id);
		Carro carroBD = carroOptional.get();
		
		if(StringUtils.hasLength(carro.getModelo())) {
			carroBD.setModelo(carro.getModelo());
		}
		
		if(StringUtils.hasLength(carro.getMarca())) {
			carroBD.setMarca(carro.getMarca());
		}
		
		if(carro.getAno()!= null) {
			carroBD.setAno(carro.getAno());
		}
		
		carroBD = carrosRepository.save(carroBD);
				
		return carroBD;
	}


}

