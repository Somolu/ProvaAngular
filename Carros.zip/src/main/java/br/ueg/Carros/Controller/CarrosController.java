package br.ueg.Carros.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.ueg.Carros.model.Carro;
import br.ueg.Carros.service.CarrosService;



@RestController
@RequestMapping(path = "/carros")
public class CarrosController {
	
	@Autowired
	private CarrosService carrosService;
	
	@GetMapping()
	public List<Carro> listarTodos(){
		return carrosService.listar();
	}
	
	@PostMapping
	public Carro incluir(@RequestBody Carro carro) {
		return carrosService.incluir(carro);
	}
	
	@GetMapping(path = "/{idCarro}")
	public Carro getCarro(@PathVariable("idCarro")Integer id) {
		return carrosService.getCarro(id);
	}
	
	@GetMapping(path = "marca/{marca}")
	public List<Carro> getCarroByMarca(@PathVariable("marca")String marca){
		return carrosService.getCarroByMarca(marca);
	}
	
	@DeleteMapping( path = "{idCarro}")
	public Carro remover(@PathVariable("idCarro") Integer id) {
		return carrosService.remover(id);
	}
	
	@PatchMapping( path = "update/{idCarro}")
	public Carro alterar(@RequestBody Carro carro, @PathVariable("idCarro") Integer id) {
		return carrosService.alterar(carro, id);
	}
	


}