package br.ueg.Carros.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.ueg.Carros.model.Carro;


@Repository
public interface CarrosRepository extends JpaRepository<Carro, Integer>{
	List<Carro> findByModelo(String modelo);
	
	List<Carro> findByMarca(String marca);

	@Query("" +
            "SELECT CASE WHEN COUNT(a) > 0 THEN " +
            "TRUE ELSE FALSE END " +
            "FROM Carro a " +
            "WHERE a.modelo = ?1"
    )
	Boolean existeModelo(String modelo);

}