package br.ueg.Carros;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import br.ueg.Carros.model.Carro;
import br.ueg.Carros.repository.CarrosRepository;

@SpringBootApplication
public class CarrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarrosApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner run(CarrosRepository repository) {
		return args -> {
			Carro a1 = new Carro(1,"Corsa","Chevrolet",2010);
			repository.save(a1);
			Carro a2 = new Carro(2,"Civic","Honda",2016);
			repository.save(a2);
		};
	}
}
