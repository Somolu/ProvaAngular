import { Component, OnInit } from '@angular/core';
import { Carro } from '../shared/carro';
import { CarroService } from '../shared/carro.service';

@Component({
  selector: 'app-carro-list',
  templateUrl: './carro-list.component.html',
  styleUrls: ['./carro-list.component.css']
})
export class CarroListComponent implements OnInit {

 carros: Carro[] = [];

  constructor(private CarroService: CarroService) { }

  ngOnInit(): void {
    console.log("Antes")

    this.CarroService.getCarro().subscribe((carros:Carro[]) =>{
      console.log("Carro",carros)
      this.carros = carros;
    })
  }

  confirmaRemocao(carro: Carro){
    let mensagem= "Deseja remover o carro: "+carro.modelo+" "+carro.marca+ ",Id :"+carro.id+"?";
    if(confirm(mensagem)){
   this.CarroService.remover(carro.id).subscribe((carro)=>{
    let carroIdx = this.carros.findIndex( (value) => value.id == carro.id);
    this.carros.splice(carroIdx, 1);
    alert("Carro removido com exito!!");
   } );
  }
}
}
