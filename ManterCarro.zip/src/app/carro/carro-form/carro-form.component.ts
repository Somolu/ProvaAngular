import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Carro } from '../shared/carro';
import { CarroService } from '../shared/carro.service';

@Component({
  selector: 'app-carro-form',
  templateUrl: './carro-form.component.html',
  styleUrls: ['./carro-form.component.css']
})
export class CarroFormComponent implements OnInit {
  carro: Carro = new Carro();

  constructor(private carroService: CarroService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id'); //pegar na rota atual o prametro especificado na rota
    if(id){

   this.carroService.getByid(parseInt(id)).subscribe( (carro) => {


    if(carro){
      this.carro =carro;
    }
  }, erro =>{
    alert("Erro ao buscar o carro com id:"+id)
  });
  }
}

  public salvar(carro: Carro){
    let acao="criado";
    if(!carro.id){
      acao = "alterado";
    }
    this.carroService.salvar(carro).subscribe((carro)=> {
      alert("Carro "+acao+" criado com sucesso, Id:"+ carro.id);
      console.log(carro);
      this.carro = carro;
      this.router.navigate(['carro'])
    }, erro => {
      console.log(erro);
      alert(erro?.error?.message);
      //alert("Não foi possivel salvar")
      console.log(erro);
    }
)
  }

}
