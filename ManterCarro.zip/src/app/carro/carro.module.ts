import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CarroComponent } from './carro.component';
import { CarroFormComponent } from './carro-form/carro-form.component';
import { CarroListComponent } from './carro-list/carro-list.component';
import { RouterModule } from '@angular/router';
import { CarroRoutes } from './carro.routing';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    CarroComponent,
    CarroFormComponent,
    CarroListComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    RouterModule.forChild(CarroRoutes)
  ]
})
export class CarroModule { }
