import { Routes } from "@angular/router";
import { CarroFormComponent } from "./carro-form/carro-form.component";
import { CarroListComponent } from "./carro-list/carro-list.component";
import { CarroComponent } from "./carro.component";

export const CarroRoutes: Routes = [
  {
    path: "carro",
    component: CarroComponent,
    children: [
      {
        path: "",
        component: CarroListComponent
      },
      {
        path: "novo",
        component: CarroFormComponent
      },
      {
        path: "editar/:id",
        component: CarroFormComponent
      }
    ]
  },
];
