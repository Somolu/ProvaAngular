import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Aluno } from 'ManterAluno/src/app/aluno/shared/aluno';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Carro } from './carro';


@Injectable({
  providedIn: 'root'
})
export class CarroService {
  urlBackend: string = "http://localhost:8080"

  constructor(private http: HttpClient) {

  }
  public getCarro(): Observable<Carro[]>{
    return this.http.get<Carro[]>(this.urlBackend+"/carros/");
  }
  public salvar(carro: Carro): Observable<Carro>{
    if(!carro.id){
    return this.http.post<Carro>(this.urlBackend+"/carros/",carro)
  }else{
    return this.http.patch<Carro>(this.urlBackend+"/carros/"+carro.id, carro)
  }
  }
  public getByid(id: number): Observable<Carro>{
   return this.http.get<Carro>(this.urlBackend+"/carros/"+id)
 }
 public remover(id: number): Observable<Carro>{
  return this.http.delete<Carro>(this.urlBackend+"/carros/"+id)
}

}
