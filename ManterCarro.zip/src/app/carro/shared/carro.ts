export class Carro {
  id!: number;
  marca!: string;
  modelo!: string;
  ano!: number;
  //getCarro: any;
  //contorna o erro mas não corrige
}
